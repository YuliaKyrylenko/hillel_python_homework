class GroupSizeLimitError(Exception):
    pass